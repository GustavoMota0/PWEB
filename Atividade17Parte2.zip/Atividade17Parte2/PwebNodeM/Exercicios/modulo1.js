var texto = "Observe que essa mensagem vem do modulo1";
module.exports = texto;